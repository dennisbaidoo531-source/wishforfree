WISH CARD STUDIO - PUBLIC WEBSITE PACKAGE
Dennis Interface For Wishes

This folder is a complete website. It is one file (index.html) with no server,
no database and no sign-up. Put it on any free static host and anyone can open
the link and use it for free.

------------------------------------------------------------
OPTION 1: Netlify Drop (easiest, about 1 minute, no account needed to try)
------------------------------------------------------------
1. Go to https://app.netlify.com/drop
2. Drag this whole folder (or the index.html file) onto the page.
3. You get a public link straight away. Create a free account to keep it
   permanently and to choose a nicer name, e.g. dennis-wishes.netlify.app

------------------------------------------------------------
OPTION 2: GitHub Pages (free, permanent)
------------------------------------------------------------
1. Create a free account at https://github.com
2. Click New repository. Name it, for example, wish-card-studio. Make it Public.
3. Click "uploading an existing file" and upload index.html. Commit.
4. Open Settings > Pages. Under "Build and deployment", set Source to
   "Deploy from a branch", choose the main branch and the / (root) folder. Save.
5. After a minute your site is live at
   https://YOUR-USERNAME.github.io/wish-card-studio/

------------------------------------------------------------
OPTION 3: Cloudflare Pages (free, fast worldwide)
------------------------------------------------------------
1. Create a free account at https://dash.cloudflare.com
2. Go to Workers & Pages > Create > Pages > Upload assets.
3. Name the project, upload this folder, and click Deploy.
4. Your site is live at https://YOUR-PROJECT.pages.dev

------------------------------------------------------------
GOOD TO KNOW
------------------------------------------------------------
- Visitors need internet for the card lettering (Google Fonts). Without it the
  page still works and uses ordinary fonts.
- Cards are saved in each visitor's own browser, not on your host. You never
  store anyone's photos or names.
- "Save as PNG/JPG" downloads straight to the visitor's device.
- A custom domain (like wishes.yourname.com) can be added later on any of the
  hosts above.
